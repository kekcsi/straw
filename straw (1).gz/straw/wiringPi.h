// a mocked wiringNP implementation for testing without GPIO
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define INPUT 0
#define OUTPUT 1
#define LOW 0
#define HIGH 1

#define _ROT_PER_SEC 16
#define _CYCLE_NSEC (1000000000/_ROT_PER_SEC)
#define _RASTER_PER_CYCLE 768
#define _RASTER_NSEC (_CYCLE_NSEC/_RASTER_PER_CYCLE)

char screen[1024][3];

void bye(void) {
    int i, j;
    FILE *f = fopen("/tmp/straw.dump", "w");

    for (i = 0; i < 192; ++i) {
        for (j = 0; j < 3; ++j) {
            fprintf(f, "%c%c", screen[i][j] + 48, screen[i + 384][j] + 48);
        }
        fprintf(f, "\n");
    }

    fclose(f);
}

void wiringPiSetup() {}

void pinMode(int pin, int direction) {}

// simulate rotation based on real time clock
int digitalRead(int pin) {
    struct timespec now;

    clock_gettime(CLOCK_REALTIME, &now);
    return now.tv_nsec%_CYCLE_NSEC < _RASTER_NSEC*3;
}

int led_for(int pin) {
    switch (pin) {
        case 12: return 0;
        case 11: return 1;
        case 22: return 2;
        case 13: return 3;
        case 15: return 4;
    }
}

unsigned rotation(unsigned unit_per_cycle);

void digitalWrite(int pin, int value) {
    struct timespec now;
    static int cnt = 0;

    int x = rotation(768);
    int y = led_for(pin);
    screen[x][y] += value;
    if (value && cnt++ == 600) bye();
}
