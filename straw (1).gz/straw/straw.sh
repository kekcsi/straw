#/bin-bash

# coordinator
#     * convert font file to 256-color uncompressed windows bmp
#     * mkfifo ascii2disp.pipe
#     * mkfifo control-command-input.pipe
#     * load variable-values.dat, constant-values.dat
#     * create uniquely named temp files for semaphore and shared memory
#     * start further processes

#!/bin/bash

INSTANCE_HOME="$(mktemp -d -t straw.XXXXXXXXXX)"
echo "Instance home: $INSTANCE_HOME"

clean_up() {
    # save trapped signal
    err=$?

    # interrupt all daemons
    kill $(cat "$INSTANCE_HOME/text-input.pid")
    rm "$INSTANCE_HOME/text-input.pid"
    kill -2 $(cat "$INSTANCE_HOME"/*.pid)

    # unlink fifos (they get closed once all other processes also unlink)
    exec 4>&-
    exec 5>&-

    # remove all temporary files
    rm -fr "$INSTANCE_HOME"

    # re-raise the original signal to the default handler
    trap '' INT
    exit $err
}

# only SIGINT results in a clean exit
trap clean_up INT

# load configuration (WIDTH, STRAW_FONT etc.)
#     UPDATE_TIME number of periods when the semaphore is free for update;
#             set low values to prevent delayed start of display loop
#             due to slow updates
#     SAVE_PERIOD save period of variables.sh
#     WIDTH number of rasters displayed visually at a time
. constants.sh

# load saved variables (CIRCLE_TIME, RASTER_OFFSET, SPACING, PROPORTIONAL etc.)
#     RASTER_OFFSET shm variable initial value
#     CIRCLE_TIME shm variable initial value
#     SPACING number of all-dark rasters between characters displayed
#     PROPORTIONAL skip all-zero rasters in the font?
CIRCLE_TIME=768 # default of defaults
RASTER_OFFSET=0 # default of defaults
if [ -e variables.sh ]
then
    . variables.sh
fi

# convert font file to raw pixel data file
#TODO
FONT_BMP="$STRAW_FONT"

# make command-interface named pipe
CMD_NAME="$INSTANCE_HOME/cmd.pipe"
mkfifo "$CMD_NAME"

# make text-to-display named pipe
TXT_NAME="$INSTANCE_HOME/txt.pipe"
mkfifo "$TXT_NAME"

# posix object names contain INSTANCE_ID in order to make'em unique over the OS
INSTANCE_ID="$(basename "$INSTANCE_HOME")"

# ID for the shared memory holding raster data to display, vars, and semaphore
SHM_NAME="/$INSTANCE_ID.shm"

# start rasterizer process
./rasterizer "$TXT_NAME" "$FONT_BMP" "$SHM_NAME" "$WIDTH" "$SPACING" "$PROPORTIONAL" "$TEXT_MAX" > "$INSTANCE_HOME/rasterizer.pid" || exit 10

# start command-interface process (receive on FIFO, write shm, save vars)
#command-interface "$CMD_NAME" "$SHM_NAME" > "$INSTANCE_HOME/command-interface.pid"

# start display-driver process (sensor read, timing, LED control)
nice -20 ./disp-driver "$SHM_NAME" "$WIDTH" "$UPDATE_TIME" "$CIRCLE_TIME" "$RASTER_OFFSET" > "$INSTANCE_HOME/disp-driver.pid" || exit 20
#width, update_time, circle_time, offset
    # echo "
    # set follow-fork-mode child
    # run "$SHM_NAME" "$WIDTH" "$UPDATE_TIME" "$CIRCLE_TIME" "$RASTER_OFFSET"
    # bt
    # "| gdb disp-driver

# start text-input process
./text-input.sh "$TXT_NAME"& disown
echo $! > "$INSTANCE_HOME/text-input.pid"

# start button-driver process (listen on button input, feed command-interface)
#button-driver "$CMD_NAME" > "$INSTANCE_HOME/button-driver.pid"

# keep named pipes open while this process runs
#exec 4>"$CMD_NAME"
exec 5>"$TXT_NAME"

sleep 1

while true
do
    for p in "$INSTANCE_HOME"/*.pid
    do
        echo -n "$(basename -s .pid $p) "
        pid="$(cat $p)"
        kill -0 $pid || exit 100
        echo running fine with pid $pid
    done

    echo All systems A-OK. Press Enter to check again. Ctrl-C to stop.

    read
done

clean_up
