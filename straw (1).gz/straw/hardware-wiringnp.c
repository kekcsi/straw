/* hardware.h implementation in WiringNP */

// for testing without GPIO: gcc -c -o hardware.o hardware-wiringnp.c -I.
// when linking a user of this library, add -lpthread -lrt

#include "wiringPi.h"
#include <unistd.h>
#include <pthread.h>
#include <string.h>
#include <semaphore.h>

// number of rows actually used
#ifndef HEIGHT
#define HEIGHT 5
#endif

// number of bits the structures are capable to store for LED control
#define HEIGHT_MAX 8

// microseconds to sleep between two reads
#ifndef SENSOR_POLL_PERIOD
#define SENSOR_POLL_PERIOD 50
#endif

int led_pins[HEIGHT_MAX];
int rot0_pin;

long cycle = 0; // duration of the last full cycle
struct timespec t0; // time when rot0 signal last observed
sem_t t_sem; // semaphore protecting vars from accessing from both threads

pthread_t rot_thread;
volatile int hardware_initialized = 0;

// calucate microsec duration between timespec values
long diff_timespec(struct timespec t0, struct timespec t1) {
    return (t1.tv_sec - t0.tv_sec)*1000000L +
            (t1.tv_nsec/1000L - t0.tv_nsec/1000L);
}

// do this on a background thread to catch rot0 signals
void* listen_sensor(void *arg) {
    struct timespec now, t0prev;
    hardware_initialized = 1;

loop:
    while (digitalRead(rot0_pin) == LOW) {
        usleep(SENSOR_POLL_PERIOD);
    }

    // record the time _before_ waiting for semaphore
    clock_gettime(CLOCK_MONOTONIC_RAW, &now);

    // atomically swap time stamps and update cycle time
    sem_wait(&t_sem);
    memcpy(&t0prev, &t0, sizeof(struct timespec));
    memcpy(&t0, &now, sizeof(struct timespec));
    cycle = diff_timespec(t0prev, now);
    sem_post(&t_sem);

    while (digitalRead(rot0_pin) == HIGH) {
        usleep(SENSOR_POLL_PERIOD);
    }

    goto loop;
}

void clean_up_hardware() {
    pthread_cancel(rot_thread);
    sem_destroy(&t_sem);
}

void init_hardware() {
    int i;

    wiringPiSetup();

    rot0_pin = 7; // only GPIO
    led_pins[0] = 12; // only GPIO

    // sacrificing UART2 pins
    led_pins[1] = 11;
    led_pins[2] = 22;
    led_pins[3] = 13;
    led_pins[4] = 15;

    // even more pins? Overlap SPI
    led_pins[5] = 19;
    led_pins[6] = 21;
    led_pins[7] = 23;

    pinMode(rot0_pin, INPUT);

    for (i = 0; i < HEIGHT; ++i) {
        pinMode(led_pins[i], OUTPUT);
    }

    sem_init(&t_sem, 0, 1);

    if (pthread_create(&rot_thread, NULL, listen_sensor, NULL)) {
        exit(95);
    }

    while (!hardware_initialized) usleep(SENSOR_POLL_PERIOD);
}

unsigned rotation(unsigned unit_per_cycle) {
    struct timespec t0fetch;
    struct timespec now;
    long cycle_fetch = 0;
    long elapsed;

    // fetch time data atomically to thread-local tmp vars
    sem_wait(&t_sem);
    memcpy(&t0fetch, &t0, sizeof(struct timespec));
    cycle_fetch = cycle;
    sem_post(&t_sem);

    if (cycle_fetch == 0) {
        // not yet done a full cycle, cannot interpolate: simulate no rotation
        return 0;
    }

    // record the time after waiting for semaphore
    clock_gettime(CLOCK_MONOTONIC_RAW, &now);

    // interpolate in-cycle time, assuming the cycle lasts as long as the last
    elapsed = diff_timespec(t0fetch, now);
    return (unsigned)(elapsed*(long)unit_per_cycle/cycle_fetch);
}

int phase = 0;
int bit_inc = 2;

// light up specified LEDs
void lights(unsigned char byte) {
    int bit_idx, led_idx = 0;

    for (bit_idx = phase; bit_idx < HEIGHT; bit_idx += bit_inc) {
        int bit_mask = 1 << bit_idx;
        digitalWrite(led_pins[led_idx++], (byte & bit_mask) ? HIGH : LOW);
    }
}

void enter_phase(int which) {
    phase = which;
}
