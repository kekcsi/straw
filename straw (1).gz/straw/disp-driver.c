/*

disp-driver /pixmap2disp.shm WIDTH UPDATE_TIME CIRCLE_TIME OFFSET
    * set semaphore
    * initialize in shm: CIRCLE_TIME, OFFSET
    * main_loop:
        * if rotation angle >= 0 but < WIDTH
            * set LED out pins to: rasters2disp[counter]
        * if rotation angle == WIDTH
            * release semaphore
            * sleep UPDATE_TIME usecs
            * set semaphore
    * goto main_loop

*/

// compile with hardware.o
// gcc disp-driver.c hardware.o -o disp-driver -lrt -lpthread -g

#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <signal.h>
#include <semaphore.h>
#include <time.h>

#include "shm.h"
#include "hardware.h"
#include "common.h"

#ifndef SENSOR_POLL_PERIOD
#define SENSOR_POLL_PERIOD 50
#endif

#define ARGC 6

int shm_fd = -1;
char *shm_name;
struct display_state *shm = MAP_FAILED;

#ifdef WANT_LOG
FILE *log_fp = NULL;
#define log_dbg(...) do {\
    time_t rawtime;\
    time(&rawtime);\
    fprintf(log_fp, "%24.24s | ", ctime(&rawtime));\
    fprintf(log_fp, __VA_ARGS__);\
    fflush(log_fp);\
} while (0)
#else
#define log_dbg(...) do {} while (0)
#endif

void clean_up(int signum)
{
    clean_up_hardware();

    sem_destroy(&shm->sem_id);
    shm_unlink(shm_name);

    if (shm_fd >= 0) {
        close(shm_fd);
    }

    clean_up_common();

    // re-raise with default handler
    signal(signum, SIG_DFL);
    raise(signum);
}

int main(int argc, char **argv) {
    int oflags = O_RDWR;
    int i;
    int width, update_time, circle_time, offset;
    pid_t process_id;
    pid_t sid;
    unsigned rot, rot_tgt;
    int state;
    int steps = 1, delay = SENSOR_POLL_PERIOD;

    reqargc(ARGC);

    defclarg("disp-driver");
    defclarg("/pixmap2disp.shm");
    defclarg("WIDTH");
    defclarg("UPDATE_TIME");
    defclarg("CIRCLE_TIME");
    defclarg("OFFSET");

    char *name = argv[1];
    nclarg(2, &width);
    nclarg(3, &update_time);
    nclarg(4, &circle_time);
    nclarg(5, &offset);

    shm_fd = shm_open(name, oflags, 0644);
    if (shm_fd < 0) {
        perror("opening shared memory object");
        exit(10);
    }

    off_t length = sizeof(struct display_state) + width;

    shm = (struct display_state*) mmap(NULL, length,
            PROT_READ|PROT_WRITE, MAP_SHARED, shm_fd, 0);

    if (shm == MAP_FAILED) {
        perror("mapping shared memory object");
        exit(50);
    }

    // fork and daemonize child
    process_id = fork();

    if (process_id < 0) {
        perror("fork");
        exit(100);
    }

    if (process_id > 0) {
        printf("%d\n", process_id);

        // exit the initializing process
        exit(0);
    }

    // daemonize the child process
#ifdef WANT_LOG
    log_fp = fopen("/tmp/straw.log", "a");
#endif
    //log_dbg("daemonize the child process\n");
    umask(0);
    sid = setsid();
    //log_dbg("sid %d\n", sid);
    if(sid < 0) exit(1);
    chdir("/");
    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);
    //log_dbg("survived\n");

    //log_dbg("set up signal handler\n");
    if (signal(SIGINT, clean_up) == SIG_ERR) {
        exit(30);
    }
    //log_dbg("survived\n");

    init_hardware();

    //log_dbg("waiting for semaphore\n");
    sem_wait(&shm->sem_id);
    //log_dbg("got that semaphore, initializing shm vars\n");
    shm->offset = offset;
    shm->circle_time = circle_time;
    state = 0;
    rot = rot_tgt = 0;
    //log_dbg("survived, main loop starts\n");

main_loop:
    steps = 0;

    while (rot_tgt == rot) {
        ++steps;

        usleep(delay);
        rot_tgt = rotation(shm->circle_time);
    }

    if (steps > 2 && state == 0) { // 2 steps are safe but eco
        // slept way too few
        log_dbg("rotation update was %d usecs, %d tries\n", delay, steps);

        ++delay;
    }

    if (rot_tgt > shm->circle_time - 1) {
        rot_tgt = shm->circle_time - 1;
    }

    //log_dbg("step by step %u --> %u\n", rot, rot_tgt);
    //log_dbg("circle_time %d, offset %d\n", shm->circle_time, shm->offset);
    steps = 0;
    while (rot != rot_tgt) {
        int ras_idx, phase;

        ++steps;

        // rot must be incremented one by one without skips
        rot = (rot + 1)%shm->circle_time;
        ras_idx = rot%(shm->circle_time/2) - shm->offset; // may be < 0
        phase = rot >= (shm->circle_time/2);

        if (state == 0) {
            if (ras_idx == 0) {
                //log_dbg("entering phase %d\n", phase);
                enter_phase(phase);
                //log_dbg("entered phase %d\n", phase);
                state = 1;
            } else {
                // just increment rot until position of first raster reached
                continue;
            }
        }

        if (state == 1 && ras_idx < width) {
            lights(shm->rasters2disp[ras_idx]);
            continue;
        }

        if (state == 1 && ras_idx == width) {
            //log_dbg("releasing\n");
            sem_post(&shm->sem_id);
            //log_dbg("it's update time\n");
            // let other users of the shared memory breathe
            usleep(update_time);
            //log_dbg("update time is over\n");
            sem_wait(&shm->sem_id);
            //log_dbg("locked\n");
            state = 0;
        }
    }

    if (steps > 1 && state == 1) {
        // in state 0 update sleep may have happened
        // but in state 1 a raster has been skipped
        log_dbg("SKIPS %d\n", steps);

        delay = delay >> 1; // halve next sleeping duration
    }

    goto main_loop;
}
