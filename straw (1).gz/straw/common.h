char **_usage_args;
int _req_arg_cnt, _completeness;

#define usage(ec) _usage(ec, _req_arg_cnt)

// usage error exit
void _usage(int errorcode, int ARGC) {
    int i;

    if (ARGC == errorcode) {
        fprintf(stderr, "Bad number of arguments.\n");
    }

    fprintf(stderr, "usage:");

    for (i = 0; i < ARGC; ++i) {
        fprintf(stderr, " %s", _usage_args[i]);

        if (i == errorcode) {
            fprintf(stderr, "(!)");
        }
    }

    fprintf(stderr, "\n");

    exit(errorcode);
}

// read in a numeric command line argument
#define nclarg(i, addr) if (sscanf(argv[(i)], "%d", (addr)) == EOF) usage(i)

#define reqargc(n) do {\
    _usage_args = malloc(n*sizeof(char*));\
    _req_arg_cnt = n;\
    _completeness = 0;\
} while (0)

#define clean_up_common() free(_usage_args)

// set the user-readable usage text for each argument one by one (please do so
// before any possible usage call)
#define defclarg(text) do {\
    _usage_args[_completeness++] = (text);\
    if (_completeness == _req_arg_cnt && argc != _req_arg_cnt) {\
        _usage(_req_arg_cnt, _req_arg_cnt);\
    }\
} while (0)

#define min(a, b) (a) < (b) ? (a) : (b)
#define max(a, b) (a) > (b) ? (a) : (b)
