#!/bin/bash

while true
do
    date > $1
    sleep 1
done

# if you want a blink or scroll effect, it should be timed in this process
