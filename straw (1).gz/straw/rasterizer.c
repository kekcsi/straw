/******************************************************************************

rasterizer ascii2disp.pipe font.bmp pixmap2disp.shm WIDTH SPACING PROPORTIONAL TEXT_MAX
    * read font.bmp pixel data into font array
    * main_loop: wait for input from pipe
    * disp_raster = 0
    * wait for the semaphore in the shm
    * do rasterize to shm
    * release semaphore
    * goto main_loop

*******************************************************************************/

// Note: Link with -lrt

#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <signal.h>
#include <semaphore.h>

#include "shm.h"
#include "common.h"

#define ARGC 8

int shm_fd = -1;
char *shm_name;
struct display_state *shm = MAP_FAILED;

FILE *input_fp = NULL;

char visible_font[8*96];
int width, spacing, proportional;
char *msg = NULL;

void clean_up(int signum)
{
    sem_destroy(&shm->sem_id);
    shm_unlink(shm_name);

    if (shm_fd >= 0) {
        close(shm_fd);
    }

    if (input_fp != NULL) {
        fclose(input_fp);
    }

    free(msg);
    clean_up_common();

    // re-raise with default handler
    signal(signum, SIG_DFL);
    raise(signum);
}

void rasterize(char* text, char* pixmap, int scroll) {
    /*
    * outer: for each char in input:
        * for char_raster = input char start address in font to end:
            * when PROPORTIONAL: next if all bits 0
            * rasters2disp[disp_raster++] = font[char_raster]
            * break outer if disp_raster >= WIDTH
        * SPACING times: rasters2disp[disp_raster++] = 0
    */
    int i, j, k = 0;
    static char *font = visible_font - 32*8;

    // clear whole pixmap
    memset(pixmap, 0, width);

    // each character of the text
    for (i = 0; text[i] != 0; ++i) {
        int end;

        if (text[i] < ' ') {
            continue;
        }

        end = (text[i] + 1) << 3;

        // each raster of the character
        for (j = text[i] << 3; j < end; ++j) {
            // skip consecutive all-dark rasters in proportional mode
            if (proportional && font[j] == 0 && k > 0 && pixmap[k - 1] == 0) {
                continue;
            }

            // copy the raster data to the pixmap in the shared memory
            if (scroll > 0) {
                --scroll;
            } else {
                pixmap[k++] = font[j];
            }
            if (k >= width) break;
        }

        for (j = 0; j < spacing; ++j) {
            if (k >= width) break;

            if (scroll > 0) {
                --scroll;
            } else {
                pixmap[k++] = 0;
            }
        }

        if (k >= width) break;
    }
};

int main(int argc, char **argv) {
    char *input_name;
    char *font_name;
    int text_max;
    pid_t process_id;
    pid_t sid;
    FILE *font_fp = NULL;

    reqargc(ARGC);
    defclarg("rasterizer");
    defclarg("txt2disp.pipe");
    defclarg("font.bmp");
    defclarg("/pixmap2disp.shm");
    defclarg("WIDTH");
    defclarg("SPACING");
    defclarg("PROPORTIONAL");
    defclarg("TEXT_MAX");

    input_name = argv[1];
    font_name = argv[2];
    shm_name = argv[3];
    nclarg(4, &width);
    nclarg(5, &spacing);
    nclarg(6, &proportional);
    nclarg(7, &text_max);

    if ((font_fp = fopen(font_name, "r")) == NULL) {
        perror("opening font file");
        exit(20);
    }

    if (fread(visible_font, 8, 96, font_fp) < 95) {
        fprintf(stderr, "error reading font file\n");
        fclose(font_fp);
        exit(21);
    }

    fclose(font_fp);

    if ((shm_fd = shm_open(shm_name, O_RDWR | O_CREAT, 0644)) < 0) {
        perror("opening shared memory");
        usage(3);
    }

    off_t length = sizeof(struct display_state) + width;
    if (ftruncate(shm_fd, length) < 0) {
        perror("truncating shared memory object");
        exit(40);
    }
    shm = (struct display_state*) mmap(NULL, length,
            PROT_READ|PROT_WRITE, MAP_SHARED, shm_fd, 0);

    if (shm == MAP_FAILED) {
        perror("mapping shared memory object");
        exit(50);
    }

    if (sem_init(&shm->sem_id, /* process-shared */1, /* value */1) < 0) {
        perror("initializing semaphore");
        exit(60);
    }

    msg = (char*)malloc(text_max);

    // spawn
    process_id = fork();

    if (process_id < 0) {
        perror("fork");
        exit(100);
    }

    if (process_id > 0) {
        printf("%d\n", process_id);

        // exit the initializing process
        exit(0);
    }

    // daemonize the child process
    umask(0);
    sid = setsid();
    if(sid < 0) exit(1);
    chdir("/");
    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);

    if (signal(SIGINT, clean_up) == SIG_ERR) {
        exit(30);
    }

    // block the daemon process until the write end of the pipe is opened
    if ((input_fp = fopen(input_name, "r")) == NULL) {
        exit(70);
    }

main_loop:
    if (fgets(msg, text_max, input_fp) == NULL) exit(2);
    sem_wait(&shm->sem_id);
    rasterize(msg, shm->rasters2disp, shm->scroll);
    sem_post(&shm->sem_id);
    goto main_loop;
}
