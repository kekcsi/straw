#include <time.h>
#include <stdio.h>

void chkclk(clockid_t clock, char* nm) {
    struct timespec res, t0;
    long i;
    long ns_per_get, get_per_sec;

    clock_getres(clock, &res);
    printf("%s precision %d sec %09ld nsec (%ld ticks/sec)\n", nm, (int)res.tv_sec, res.tv_nsec, 1000000000/res.tv_nsec);

    clock_gettime(CLOCK_MONOTONIC_RAW, &t0);
    for (i = 0; i < 100000; ++i) {
        clock_gettime(clock, &res);
    }
    clock_gettime(CLOCK_MONOTONIC_RAW, &res);
    ns_per_get = (res.tv_sec - t0.tv_sec)*10000 + (res.tv_nsec/100000 - t0.tv_nsec/100000);
    get_per_sec = 1000000000/ns_per_get;
    printf("%s get performance: %ld nsec/get, %ld gets/sec\n", nm, ns_per_get, get_per_sec);

    clock_gettime(CLOCK_MONOTONIC_RAW, &t0);
    printf("%s check-back starts %d sec %09ld nsec\n", nm, (int)t0.tv_sec, t0.tv_nsec);
    for (i = 0; i < get_per_sec; ++i) {
        clock_gettime(clock, &res);
    }
    clock_gettime(CLOCK_MONOTONIC_RAW, &res);
    printf("%s check-back  ends  %d sec %09ld nsec\n", nm, (int)res.tv_sec, res.tv_nsec);
    printf("%s check-back duration %ld/100 sec\n", nm, (res.tv_sec - t0.tv_sec)*100 + (res.tv_nsec/10000000 - t0.tv_nsec/10000000));
}

int main() {
    struct timespec res;

    chkclk(CLOCK_MONOTONIC_RAW, "RAW");
    chkclk(CLOCK_MONOTONIC_COARSE, "COARSE");

    return 0;
}
