/* interface to implement for different hardware */

void init_hardware();

// return rotation angle from reference point
unsigned rotation(unsigned unit_per_cycle);

// light up specified LEDs
void lights(unsigned char byte);

// support for multiphase operation (interlace)
void enter_phase(int which);

void clean_up_hardware();
