/******************************************************************************

control-interface pixmap2disp.shm control-command-input.pipe variable-values.dat SAVE_PERIOD
    * main_loop: wait for command on pipe with timeout of SAVE_PERIOD
    * get the semaphore in the shm
    * execute command if any
    * no command after timeout: save values to buffered variable-values.dat
    * release semaphore
    * flush variable-values.dat
    * goto main_loop
*/

// Note: Link with -lrt

#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <signal.h>
#include <semaphore.h>

#include "shm.h"


#ifndef CMD_MAX
#define CMD_MAX 160
#endif

int shm_fd = -1;
char *shm_name;
char *persist_name;
struct display_state *shm = MAP_FAILED;

FILE *input_fp = NULL;

void clean_up(int signum)
{
    sem_destroy(&shm->sem_id);
    shm_unlink(shm_name);

    if (shm_fd >= 0) {
        close(shm_fd);
    }

    if (input_fp != NULL) {
        fclose(input_fp);
    }

    // re-raise with default handler
    signal(signum, SIG_DFL);
    raise(signum);
}

void execute(char* cmd) {
    /*
    * command WIDEN/NARROW: update CIRCLE_TIME in shm
    * command SHIFT LEFT/RIGHT: update OFFSET in shm
    */
}

int main(int argc, char **argv) {
    char *input_name;
    char msg[CMD_MAX];
    pid_t process_id;
    pid_t sid;
    int period;

    shm_name = argv[1];
    input_name = argv[2];
    persist_name = argv[3];

    if (sscanf(argv[4], "%d", &period) == EOF) exit(4);

    if ((shm_fd = shm_open(shm_name, O_RDWR | O_CREAT, 0644)) < 0) {
        perror("opening shared memory");
        exit(3);
    }

    off_t length = sizeof(struct display_state) + width;
    if (ftruncate(shm_fd, length) < 0) {
        perror("truncating shared memory object");
        exit(40);
    }
    shm = (struct display_state*) mmap(NULL, length,
            PROT_READ|PROT_WRITE, MAP_SHARED, shm_fd, 0);

    if (shm == MAP_FAILED) {
        perror("mapping shared memory object");
        exit(50);
    }

    if (sem_init(&shm->sem_id, /* process-shared */1, /* value */1) < 0) {
        perror("initializing semaphore");
        exit(60);
    }

    // spawn
    process_id = fork();

    if (process_id < 0) {
        perror("fork");
        exit(100);
    }

    if (process_id > 0) {
        printf("%d\n", process_id);

        // exit the initializing process
        exit(0);
    }

    // daemonize the child process
    umask(0);
    sid = setsid();
    if(sid < 0) exit(1);
    chdir("/");
    close(STDIN_FILENO);
    close(STDOUT_FILENO);
    close(STDERR_FILENO);

    if (signal(SIGINT, clean_up) == SIG_ERR) {
        exit(30);
    }

    // init shared var
    sem_wait(&shm->sem_id);
    shm->scroll = 0;
    sem_post(&shm->sem_id);

    // this call blocks the daemon process while the write end of the pipe
    // is not yet opened
    if ((input_fp = fopen(input_name, "r")) == NULL) {
        exit(70);
    }

main_loop:
    if (fgets(msg, CMD_MAX, input_fp) == NULL) exit(2); //TODO timeout
    sem_wait(&shm->sem_id);
    execute(msg);
    sem_post(&shm->sem_id);
    goto main_loop;
}
