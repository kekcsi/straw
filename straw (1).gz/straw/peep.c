// look into shared memory for debugging purposes

#include <stdio.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <sys/stat.h>        /* For mode constants */
#include <fcntl.h>           /* For O_* constants */
#include <unistd.h>
#include <string.h>
#include <semaphore.h>

#include "shm.h"

int main(int argc, char **argv) {
    int oflags = O_RDWR;
    int i;
    int width;

    char *name = argv[1];
    sscanf(argv[2], "%d", &width);

    int fd = shm_open(name, oflags, 0644);
    if (fd < 0) {
        perror("opening shared memory object");
        exit(10);
    }

    off_t length = sizeof(struct display_state) + width;

    u_char *ptr = (u_char *) mmap(NULL, length, PROT_READ|PROT_WRITE,
        MAP_SHARED, fd, 0);

    if (ptr == MAP_FAILED) {
        perror("mapping shared memory object");
        exit(50);
    }

#define PLOT(byte)  \
  ((byte) & 0x80 ? '1' : '.'), \
  ((byte) & 0x40 ? '1' : '.'), \
  ((byte) & 0x20 ? '1' : '.'), \
  ((byte) & 0x10 ? '1' : '.'), \
  ((byte) & 0x08 ? '1' : '.'), \
  ((byte) & 0x04 ? '1' : '.'), \
  ((byte) & 0x02 ? '1' : '.'), \
  ((byte) & 0x01 ? '1' : '.')

    for (i = sizeof(struct display_state); i < length; i++)
        printf("%d\t%c%c%c%c%c%c%c%c\n", (int)(ptr[i]), PLOT((int)(ptr[i])));

    close(fd);
    return 0;
}
