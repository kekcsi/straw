/*
The shared memory:
    semaphore protecting the whole shared memory from concurrent access
    OFFSET in periods: display position relative to 0 degrees signal point
            shifts the text on the screen to the right with that many rasters
    CIRCLE_TIME target value for number of periods per rotation
                adjusts screen width
    rasters2disp: buffer of 7×WIDTH pixels to be displayed
*/

struct display_state {
    // semaphore protecting the rest of shared memory from concurrent access
    sem_t sem_id;

    // shared variables
    int offset;
    int circle_time;
    int scroll;

    // this symbol will hold the end address of the struct
    char rasters2disp[0];
};
